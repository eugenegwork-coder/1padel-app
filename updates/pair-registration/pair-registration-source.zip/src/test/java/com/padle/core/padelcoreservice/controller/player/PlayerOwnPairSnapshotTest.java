package com.padle.core.padelcoreservice.controller.player;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.padle.core.padelcoreservice.dto.TournamentRegistrationDto;
import com.padle.core.padelcoreservice.model.PlayerPadel;
import com.padle.core.padelcoreservice.model.Owner;
import com.padle.core.padelcoreservice.model.enums.RegistrationStatus;
import com.padle.core.padelcoreservice.repository.PlayerRepository;
import com.padle.core.padelcoreservice.service.DoubleTournamentRegistrationService;
import com.padle.core.padelcoreservice.service.TournamentService;
import org.junit.jupiter.api.Test;
import java.util.Map;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PlayerOwnPairSnapshotTest {
    private final TournamentService service = mock(TournamentService.class);
    private final PlayerDashboardController controller = new PlayerDashboardController(
            service, new ObjectMapper(), mock(DoubleTournamentRegistrationService.class), mock(PlayerRepository.class));

    @Test void ownSnapshotUsesPrincipalAndDoesNotExposeInvitationTokensOrContacts() {
        PlayerPadel actor = PlayerPadel.builder().id(4L).build();
        TournamentRegistrationDto row = new TournamentRegistrationDto();
        row.setId(123L); row.setStatus(RegistrationStatus.WAITLIST); row.setWaitlistPosition(2);
        row.setIsDoubleRegistration(false); row.setPartnerRegistrationToken("must-not-leak");
        row.setPartnerEmail("must-not-leak@example.test"); row.setPartnerPhone("must-not-leak");
        when(service.getRegistration(42L, 4L)).thenReturn(Optional.of(row));
        var response = controller.getMyRegistration(42L, actor);
        Map<?, ?> body = (Map<?, ?>) response.getBody();
        assertEquals(200, response.getStatusCode().value()); assertNotNull(body);
        assertEquals(true, body.get("registered")); assertEquals(123L, body.get("registrationId"));
        assertEquals(RegistrationStatus.WAITLIST, body.get("status"));
        assertEquals(false, body.get("isDoubleRegistration"));
        assertFalse(body.containsKey("partnerRegistrationToken")); assertFalse(body.containsKey("partnerEmail"));
        assertFalse(body.containsKey("partnerPhone"));
        verify(service).getRegistration(42L, 4L);
    }
    @Test void missingActiveRegistrationIsNotAnInventedWaitlistOrPair() {
        when(service.getRegistration(42L, 4L)).thenReturn(Optional.empty());
        var response = controller.getMyRegistration(42L, PlayerPadel.builder().id(4L).build());
        assertEquals(Map.of("registered", false), response.getBody());
    }
    @Test void organizerCannotReadPlayerSnapshotThroughThisHandler() {
        var response = controller.getMyRegistration(42L, new Owner());
        assertEquals(400, response.getStatusCode().value()); verifyNoInteractions(service);
    }
}
