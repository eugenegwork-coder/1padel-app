import React,{useEffect,useRef,useState} from 'react';
import {ActivityIndicator,KeyboardAvoidingView,Linking,Platform,ScrollView,StyleSheet,Text,TextInput,TouchableOpacity,View} from 'react-native';
import {AuthError,PlayerRequestError} from './auth';
import {PairError,canAddPartner,canProposePair,emptyPartner,isPairEvent,pairQuote,validPartner} from './pairBooking';
import type {Candidate,Partner,PairMode,PairSnapshot,PairReceipt,createPairBooking} from './pairBooking';
import {pairCopy} from './pairCopy';
import {eventDate,eventPrice} from './schedule';
import type {Language} from './schedule';
import {messages} from './copy';
import {cancellationDeadline} from './individualBooking';
import {colors as c} from './theme';
type Phase='choose'|'partner'|'solo'|'review'|'result'|'candidates'|'proposal';
type FieldKey='first'|'last'|'phone'|'telegram';
export default function PairBookingScreen({tournamentId,gateway,language,profileName,onClose,onMyEvents,demo=false}:{tournamentId:number;gateway:ReturnType<typeof createPairBooking>;language:Language;profileName:string;onClose:()=>void;onMyEvents:()=>void;demo?:boolean}) {
 const t=pairCopy[language]; const [snapshot,setSnapshot]=useState<PairSnapshot|null>(null);const [receipt,setReceipt]=useState<PairReceipt|null>(null);
 const [phase,setPhase]=useState<Phase>('choose');const [mode,setMode]=useState<PairMode>('WITH_PARTNER');const [adding,setAdding]=useState(false);
 const [partner,setPartner]=useState<Partner>({...emptyPartner});const [manual,setManual]=useState(false);const [query,setQuery]=useState('');const [activeField,setActiveField]=useState<FieldKey|null>(null);
 const [matches,setMatches]=useState<Partner[]>([]);const [looking,setLooking]=useState(false);const [share,setShare]=useState(false);
 const [candidates,setCandidates]=useState<Candidate[]|null>(null);const [target,setTarget]=useState<Candidate|null>(null);
 const [busy,setBusy]=useState(false);const [loading,setLoading]=useState(true);const [uncertain,setUncertain]=useState(false);const [error,setError]=useState<AuthError|null>(null);
 const [sharePreview,setSharePreview]=useState(false);const running=useRef(false);const version=useRef(0);
 function problem(e:unknown) {const issue=e instanceof AuthError?e:new AuthError('UNAVAILABLE');setError(issue);
  if(issue instanceof PairError&&issue.snapshot)setSnapshot(issue.snapshot);
  if(issue instanceof PairError&&issue.matches){setMatches(issue.matches);setPhase('partner');setPartner(p=>({...p,id:undefined}));}
  if(issue.code==='UNCERTAIN')setUncertain(true);
 }
 async function perform(fn:()=>Promise<void>){if(running.current)return;running.current=true;const started=version.current;setBusy(true);setError(null);
  try{await fn();}catch(e){if(started===version.current)problem(e);}finally{running.current=false;if(started===version.current){setBusy(false);setLoading(false);}}
 }
 async function check(){const started=version.current;await perform(async()=>{const next=await gateway.reconcile(tournamentId);if(started!==version.current)return;setSnapshot(next.snapshot);setUncertain(next.uncertain);setReceipt(null);setPhase(next.snapshot.own.registered?'result':'choose');});}
 useEffect(()=>{version.current++;void check();return()=>{version.current++;};},[gateway,tournamentId]);
 const lookup=manual?(activeField?partner[activeField]:''):query;
 useEffect(()=>{let alive=true;setMatches([]);if(phase!=='partner'||partner.id||lookup.trim().length<2){setLooking(false);return;}
  setLooking(true);const timer=setTimeout(()=>{gateway.search(tournamentId,lookup).then(rows=>{if(alive)setMatches(rows);}).catch(e=>{if(alive)problem(e);}).finally(()=>{if(alive)setLooking(false);});},300);
  return()=>{alive=false;clearTimeout(timer);};
 },[gateway,tournamentId,lookup,phase,partner.id,manual]);
 const event=snapshot?.event;const own=snapshot?.own;const status=receipt?.status??own?.status;
 const closed=!!event&&(!event.registrationOpen||event.status!=='REGISTRO_ABIERTO'||Date.parse(event.startsAt)<=Date.now());
 const ready=!!(own?.isDouble&&own.partnerId)||!!(receipt&&mode==='WITH_PARTNER'&&['CONFIRMED','WAITLIST'].includes(receipt.status));
 const label=(status&&t[status as keyof typeof t])||t.result;
 function choose(value:PairMode){setMode(value);setAdding(false);setError(null);setReceipt(null);setPhase(value==='WITH_PARTNER'?'partner':'solo');}
 function edit(field:FieldKey,value:string){setPartner(p=>({...p,id:undefined,[field]:value}));setActiveField(field);setError(null);}
 function select(p:Partner){setPartner({...p});setActiveField(null);setQuery('');setMatches([]);setError(null);}
 async function external(url:string){try{if(demo){setSharePreview(true);return;}await Linking.openURL(url);}catch{setError(new AuthError('UNAVAILABLE'));}}
 const shareText=event?`${messages[language][event.type]} · ${eventDate(event.startsAt,event.timeZone,language)} · ${event.club.name}\n${label}\nhttps://1-padel.com/app/?event=${event.id}`:'';
 let errorText=t.unavailable;
 if(error instanceof PlayerRequestError)errorText=error.needLevel?t.needLevel:error.detail||t.unavailable;
 else if(error){const key:Record<string,keyof typeof t>={CHANGED:'changed',CLOSED:'closed',EXISTING:'existing',INVALID_PARTNER:'invalid',PARTNER_UNAVAILABLE:'unavailablePartner',MATCH_REQUIRED:'matchRequired',UNCERTAIN:'uncertain'};errorText=t[key[error.code]??'unavailable'];}
 const allowRetry=!error||error.code==='CHANGED';
 function beginAdd(){setAdding(true);setMode('WITH_PARTNER');setPartner({...emptyPartner});setReceipt(null);setError(null);setPhase('partner');}
 function showCandidates(){const started=version.current;setCandidates(null);setPhase('candidates');void perform(async()=>{const rows=await gateway.candidates(tournamentId);if(started===version.current)setCandidates(rows);});}
 function matchRows(){return !!matches.length&&<View style={s.notice}><Text style={s.section}>{t.matches}</Text>{matches.map(p=><TouchableOpacity key={p.id} accessibilityRole="button" accessibilityLabel={`${t.selected}: ${p.first} ${p.last}`} onPress={()=>select(p)} style={s.person}><View style={{flex:1}}><Text style={s.fact}>{p.first} {p.last}</Text><Text style={s.small}>{p.level||'—'}{p.phone?` · WhatsApp …${p.phone.replace(/\D/g,'').slice(-4)}`:''}</Text></View><Text style={s.link}>＋</Text></TouchableOpacity>)}</View>;}
 return <KeyboardAvoidingView style={s.screen} behavior={Platform.OS==='ios'?'padding':undefined}>
  <View style={s.top}><Button secondary title={`‹ ${t.back}`} disabled={busy} onPress={()=>{if(phase==='review'){setPhase(mode==='WITH_PARTNER'?'partner':'solo');setError(null);}else if(phase==='partner'||phase==='solo'){setPhase(own?.registered?'result':'choose');setError(null);}else onClose();}}/><Text accessibilityRole="header" style={s.title}>{phase==='review'?t.review:phase==='partner'?t.partnerTitle:phase==='choose'?t.choose:t.title}</Text></View>
  {demo&&<Text style={s.demo}>{t.demo}</Text>}
  <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}>
   {loading&&<View style={s.center}><ActivityIndicator color={c.orange}/><Text style={s.body}>{t.loading}</Text></View>}
   {event&&<View style={s.card}><Text style={s.eventTitle}>{messages[language][event.type]}</Text><Text style={s.body}>{messages[language][event.gender]}{event.level?` · ${event.level.replaceAll('_','/')}`:''}</Text><Text style={s.fact}>{eventDate(event.startsAt,event.timeZone,language)}</Text><Text style={s.body}>{event.club.name}</Text><Text style={s.small}>{t.perPerson}: {eventPrice(event,language)}</Text></View>}
   {!loading&&event&&(!isPairEvent(event)||closed)&&<Text accessibilityRole="alert" style={s.error}>{t.closed}</Text>}
   {!loading&&event&&phase==='choose'&&!uncertain&&!closed&&isPairEvent(event)&&<View style={s.card}>{(['WITH_PARTNER','SEARCH','ADD_LATER'] as PairMode[]).map(value=><Button key={value} secondary title={value==='WITH_PARTNER'?t.withPartner:value==='SEARCH'?t.searchMode:t.laterMode} onPress={()=>choose(value)}/>)}</View>}
   {phase==='partner'&&!uncertain&&<>
    <View style={s.tabs}><Button secondary title={t.lookup} disabled={busy} onPress={()=>{setManual(false);setPartner({...emptyPartner});setQuery('');}}/><Button secondary title={t.manual} disabled={busy} onPress={()=>{setManual(true);setPartner({...emptyPartner});setActiveField(null);}}/></View>
    {!manual&&!partner.id&&<><Field label={t.query} value={query} onChange={setQuery}/>{looking&&<ActivityIndicator/>}{matchRows()}{query.trim().length>=2&&!looking&&!matches.length&&<Text style={s.body}>{t.noMatches}</Text>}</>}
    {!!partner.id&&<View style={s.notice}><Text style={s.section}>{partner.first} {partner.last}</Text><Text style={s.small}>{partner.level||'1‑Padel'}</Text><Button secondary title={t.change} onPress={()=>setPartner({...emptyPartner})}/></View>}
    {manual&&!partner.id&&<View style={s.card}>{(['first','last','phone','telegram'] as FieldKey[]).map(field=><View key={field}><Field label={t[field]} value={partner[field]} onChange={value=>edit(field,value)} phone={field==='phone'}/>{activeField===field&&(looking?<ActivityIndicator/>:matchRows())}</View>)}</View>}
   </>}
   {phase==='solo'&&!uncertain&&<View style={s.card}><Text style={s.section}>{mode==='SEARCH'?t.searchMode:t.laterMode}</Text><Text style={s.body}>{mode==='SEARCH'?t.searchHint:t.laterHint}</Text>{mode==='SEARCH'?<><TouchableOpacity accessibilityRole="checkbox" accessibilityState={{checked:share}} onPress={()=>setShare(v=>!v)} style={s.check}><Text style={s.box}>{share?'☑':'☐'}</Text><Text style={s.body}>{t.shareContacts}</Text></TouchableOpacity><Text style={s.small}>{t.shareHint}</Text></>:event&&<><Text style={s.small}>{t.partnerBy}</Text><Text style={s.fact}>{eventDate(new Date(Date.parse(event.startsAt)-86400000).toISOString(),event.timeZone,language)}</Text></>}</View>}
   {phase==='review'&&snapshot&&!uncertain&&<>
    <View style={s.card}><Text style={s.section}>{t.participants}</Text><Text style={s.fact}>{profileName}</Text><Text style={s.fact}>{mode==='WITH_PARTNER'?`${partner.first} ${partner.last}`:mode==='SEARCH'?t.searchMode:t.laterMode}</Text>{mode==='WITH_PARTNER'&&!partner.id&&<Text style={s.small}>{t.newPlayer}</Text>}{mode==='WITH_PARTNER'&&!!partner.phone&&<Text style={s.small}>WhatsApp: {partner.phone}</Text>}{mode==='WITH_PARTNER'&&!!partner.telegram&&<Text style={s.small}>Telegram: {partner.telegram}</Text>}</View>
    <View style={s.card}><Text style={s.fact}>{t.perPerson}: {eventPrice(snapshot.event,language)}</Text>{mode==='WITH_PARTNER'&&<Text style={s.fact}>{t.perPair}: {eventPrice({...snapshot.event,price:snapshot.event.price*2},language)}</Text>}<Text style={s.small}>{t.cancelBy}</Text><Text style={s.fact}>{eventDate(cancellationDeadline(snapshot.event),snapshot.event.timeZone,language)}</Text>{mode==='ADD_LATER'&&<><Text style={s.small}>{t.partnerBy}</Text><Text style={s.fact}>{eventDate(new Date(Date.parse(snapshot.event.startsAt)-86400000).toISOString(),snapshot.event.timeZone,language)}</Text></>}<Text style={s.body}>{t.noCharge}</Text><Button secondary title={t.conditions} onPress={()=>void external(snapshot.event.websiteUrl)}/></View>
   </>}
   {phase==='result'&&status&&!uncertain&&<View style={s.notice}><Text accessibilityRole="header" style={s.eventTitle}>{label}</Text>{(own?.partnerName||partner.first)&&<Text style={s.fact}>{own?.partnerName||`${partner.first} ${partner.last}`}</Text>}{(receipt?.waitlistPosition??own?.waitlistPosition)!=null&&<Text style={s.body}>{t.queue}: {receipt?.waitlistPosition??own?.waitlistPosition}</Text>}{own&&canAddPartner(own)&&<Button title={t.add} disabled={busy} onPress={beginAdd}/>} {own&&canProposePair(own)&&<Button title={t.candidates} disabled={busy} onPress={showCandidates}/>}<Button title={t.myEvents} onPress={onMyEvents}/></View>}
   {phase==='result'&&ready&&event&&!uncertain&&<View style={s.card}><Text style={s.body}>{t.shareHintDone}</Text><Button secondary title={t.shareWhatsApp} onPress={()=>void external(`https://wa.me/?text=${encodeURIComponent(shareText)}`)}/><Button secondary title={t.shareTelegram} onPress={()=>void external(`https://t.me/share/url?url=${encodeURIComponent(`https://1-padel.com/app/?event=${event.id}`)}&text=${encodeURIComponent(shareText)}`)}/><Text style={s.small}>{t.noAutomatic}</Text>{sharePreview&&<Text style={s.body}>{shareText}</Text>}</View>}
   {phase==='candidates'&&candidates&&<>{candidates.length===0&&<Text style={s.body}>{t.emptyCandidates}</Text>}{candidates.map(p=><View key={p.id} style={s.card}><Text style={s.section}>{p.name}</Text><Text style={s.small}>{p.level||'—'}</Text>{!p.shareContacts&&<Text style={s.small}>{t.hidden}</Text>}{p.shareContacts&&p.telegram&&<Text style={s.small}>{p.telegram}</Text>}<Button secondary title={t.propose} disabled={busy} onPress={()=>{setTarget(p);setPhase('proposal');}}/></View>)}</>}
   {phase==='proposal'&&target&&<View style={s.card}><Text style={s.section}>{target.name}</Text><Text style={s.body}>{t.proposal}</Text></View>}
   {error&&<Text accessibilityRole="alert" style={s.error}>{errorText}</Text>}
   {error instanceof PlayerRequestError&&error.needLevel&&<Button secondary title={t.profile} onPress={()=>void external('https://1-padel.com/perfil')}/>}
   {uncertain&&<View style={s.notice}><Text style={s.body}>{t.stillUncertain}</Text></View>}
   {!loading&&(error||uncertain)&&<Button secondary title={t.retry} disabled={busy} onPress={()=>void check()}/>}
   {!loading&&(!event||error||uncertain||closed)&&<Button secondary title={t.site} onPress={()=>void external(event?.websiteUrl??`https://1-padel.com/torneo/${tournamentId}`)}/>}
  </ScrollView>
  {['partner','solo','review','proposal'].includes(phase)&&!uncertain&&<View style={s.footer}>
   {phase==='review'&&<Text style={s.caption}>{t.confirmText}</Text>}
   <Button title={busy?t.busy:phase==='review'?adding?t.add:mode==='WITH_PARTNER'?t.register:t.submitSolo:phase==='proposal'?t.sendProposal:t.continue}
    disabled={busy||loading||closed||!allowRetry||phase==='partner'&&(!validPartner(partner)||looking)} onPress={()=>{
     if(!snapshot)return;
     if(phase==='partner'||phase==='solo'){setPhase('review');setError(null);return;}
     const started=version.current;void perform(async()=>{const value=phase==='proposal'&&target?await gateway.propose(tournamentId,pairQuote(snapshot),target.id):await gateway.submit(tournamentId,pairQuote(snapshot),mode,partner,share,adding);
      if(started!==version.current)return;setReceipt(value);setPhase('result');
      // Подтверждённый ответ не теряем, если дополнительный GET временно недоступен.
      try{const latest=await gateway.load(tournamentId);if(started===version.current)setSnapshot(latest);}catch{/* Квитанция подтверждена сервером; список можно обновить отдельно. */}
     });
    }}/>
  </View>}
 </KeyboardAvoidingView>;
}
function Button({title,onPress,disabled=false,secondary=false}:{title:string;onPress:()=>void;disabled?:boolean;secondary?:boolean}){return <TouchableOpacity accessibilityRole="button" accessibilityState={{disabled}} disabled={disabled} onPress={onPress} style={[s.button,secondary&&s.secondary,disabled&&s.disabled]}><Text style={[s.buttonText,secondary&&s.link]}>{title}</Text></TouchableOpacity>;}
function Field({label,value,onChange,phone=false}:{label:string;value:string;onChange:(v:string)=>void;phone?:boolean}){return <><Text style={s.small}>{label}</Text><TextInput accessibilityLabel={label} value={value} onChangeText={onChange} autoCapitalize="none" autoCorrect={false} keyboardType={phone?'phone-pad':'default'} maxLength={100} style={s.input}/></>;}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:c.background},top:{backgroundColor:c.white,paddingHorizontal:20,paddingBottom:14,borderBottomWidth:1,borderColor:c.line},title:{fontSize:25,lineHeight:31,fontWeight:'800',color:c.ink,marginTop:10},content:{width:'100%',maxWidth:540,alignSelf:'center',padding:18,gap:13},card:{backgroundColor:c.white,borderWidth:1,borderColor:c.line,padding:17,borderRadius:17},notice:{backgroundColor:c.greenPale,padding:17,borderRadius:17},eventTitle:{fontSize:22,lineHeight:29,fontWeight:'800',color:c.ink},section:{fontSize:16,lineHeight:23,fontWeight:'800',color:c.ink},fact:{fontSize:14,lineHeight:22,fontWeight:'700',color:c.ink,marginTop:7},body:{fontSize:13,lineHeight:21,color:c.muted,marginTop:6},small:{fontSize:11,lineHeight:18,color:c.muted,marginTop:7},caption:{fontSize:12,lineHeight:19,color:c.ink,textAlign:'center',marginBottom:7},input:{backgroundColor:c.white,borderWidth:1,borderColor:c.line,borderRadius:11,minHeight:49,padding:12,fontSize:16,color:c.ink,marginTop:6},person:{flexDirection:'row',alignItems:'center',gap:9,paddingVertical:9},link:{color:c.green,fontSize:12,fontWeight:'700'},button:{backgroundColor:c.orange,borderRadius:12,minHeight:48,padding:12,justifyContent:'center',alignItems:'center',marginTop:8},buttonText:{fontSize:14,fontWeight:'800',color:c.white,textAlign:'center'},secondary:{backgroundColor:c.white,borderWidth:1,borderColor:c.line},disabled:{opacity:.4},tabs:{flexDirection:'row',gap:9,justifyContent:'space-around'},error:{fontSize:13,lineHeight:21,color:'#A13F31'},footer:{backgroundColor:c.white,borderTopWidth:1,borderColor:c.line,paddingHorizontal:18,paddingVertical:10},center:{padding:25,alignItems:'center',gap:9},check:{flexDirection:'row',gap:9,alignItems:'center',paddingVertical:10},box:{fontSize:24,color:c.green},demo:{padding:8,textAlign:'center',fontSize:10,color:c.amber,backgroundColor:c.amberPale}});
