import React,{useEffect,useMemo,useState} from 'react';
import {ActivityIndicator,Linking,Platform,Text,TouchableOpacity,View} from 'react-native';
import {useAuth} from './AuthContext';
import {createScheduleClient} from './schedule';
import type {Language,PublicTournament} from './schedule';
import {isPairEvent} from './pairBooking';
import {isIndividualEvent} from './individualBooking';
import PairBookingScreen from './PairBookingScreen';
import IndividualBookingScreen from './IndividualBookingScreen';
import {pairCopy} from './pairCopy';
export default function BookingEntry({tournamentId,language,onClose,onMyEvents}:{tournamentId:number;language:Language;onClose:()=>void;onMyEvents:()=>void}){
 const auth=useAuth();const [event,setEvent]=useState<PublicTournament|null>(null);const [failed,setFailed]=useState(false);
 const client=useMemo(()=>createScheduleClient({baseUrl:Platform.OS==='web'&&typeof window!=='undefined'&&window.location.protocol==='https:'&&['1-padel.com','www.1-padel.com'].includes(window.location.hostname)?window.location.origin:'https://1-padel.com'}),[]);
 useEffect(()=>{let alive=true;setEvent(null);setFailed(false);client.details(tournamentId,language).then(e=>{if(alive)setEvent(e);}).catch(()=>{if(alive)setFailed(true);});return()=>{alive=false;};},[client,tournamentId,language]);
 if(event&&isPairEvent(event))return <PairBookingScreen tournamentId={tournamentId} gateway={auth.pair} language={language} profileName={auth.profile?.name??''} onClose={onClose} onMyEvents={onMyEvents}/>;
 if(event&&isIndividualEvent(event))return <IndividualBookingScreen tournamentId={tournamentId} booking={auth.booking} language={language} profileName={auth.profile?.name??''} onClose={onClose} onMyEvents={onMyEvents}/>;
 const t=pairCopy[language];return <View style={{flex:1,padding:20,gap:16}}><TouchableOpacity accessibilityRole="button" onPress={onClose}><Text>{t.back}</Text></TouchableOpacity>{failed||event?<><Text>{t.unavailable}</Text><TouchableOpacity accessibilityRole="link" onPress={()=>void Linking.openURL(event?.websiteUrl??`https://1-padel.com/torneo/${tournamentId}`)}><Text>{t.site}</Text></TouchableOpacity></>:<><ActivityIndicator/><Text>{t.loading}</Text></>}</View>;
}
