import { AuthError, PlayerRequestError } from './auth.ts';
import type { PublicTournament } from './schedule.ts';
import { bookingQuote } from './individualBooking.ts';
export type PairMode = 'WITH_PARTNER' | 'SEARCH' | 'ADD_LATER';
export type Partner = { id?: number; first: string; last: string; phone: string; telegram: string; level?: string };
export type PairOwn = { registered: boolean; id: number | null; status: string | null; waitlistPosition: number | null; registeredAt: string | null; isDouble: boolean; partnerId: number | null; partnerName: string | null };
export type PairSnapshot = { event: PublicTournament; own: PairOwn };
export type PairReceipt = { status: string; waitlistPosition: number | null };
export type Candidate = { id: number; playerId: number; name: string; level: string | null; shareContacts: boolean; telegram: string | null; phone: string | null };
const statuses = ['CONFIRMED','WAITLIST','WAITLIST_INVITED','PARTNER_INVITED','PAIR_REGISTERED','SOLO_SEARCH','SOLO_ADD_LATER','SOLO_EXPIRED'];
const rec = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const id = (v: unknown): v is number => Number.isSafeInteger(v) && Number(v) > 0;
const str = (v: unknown) => typeof v === 'string' ? v : '';
export const emptyPartner: Partner = { first: '', last: '', phone: '', telegram: '' };
export const digits = (v: string) => v.replace(/\D/g, '');
export function validPartner(p: Partner) {
  if (p.id) return id(p.id) && !!p.first.trim() && !!p.last.trim();
  return !!p.first.trim() && !!p.last.trim() && /^\+?[0-9\s\-()]{8,20}$/.test(p.phone.trim()) && digits(p.phone).length >= 8
    && (!p.telegram.trim() || /^@?[A-Za-z][A-Za-z0-9_]{4,31}$/.test(p.telegram.trim()));
}
export function isPairEvent(event: PublicTournament) { return event.modality === 'DOBLES' && ['AMERICANO_TEAMS','AMERICANO'].includes(event.type); }
export function canAddPartner(own: PairOwn) { return own.registered && (own.status === 'SOLO_ADD_LATER' || own.status === 'WAITLIST' && !own.isDouble && !own.partnerId); }
export function canProposePair(own: PairOwn) { return own.registered && ['SOLO_SEARCH','SOLO_ADD_LATER'].includes(own.status ?? ''); }
export function pairQuote(s: PairSnapshot) { return JSON.stringify([bookingQuote(s.event), s.own]); }
export function parseOwn(value: unknown): PairOwn {
  if (!rec(value) || typeof value.registered !== 'boolean') throw new AuthError('UNAVAILABLE');
  if (!value.registered) return { registered: false, id:null, status:null, waitlistPosition:null, registeredAt:null, isDouble:false, partnerId:null, partnerName:null };
  if (!id(value.registrationId) || !statuses.includes(str(value.status)) || typeof value.isDoubleRegistration !== 'boolean'
    || !(value.partnerId == null || id(value.partnerId)) || !(value.waitlistPosition == null || id(value.waitlistPosition))) throw new AuthError('UNAVAILABLE');
  return { registered:true, id:value.registrationId, status:str(value.status), waitlistPosition: value.waitlistPosition as number|null ?? null,
    registeredAt: typeof value.registrationDate === 'string' ? value.registrationDate : null, isDouble:value.isDoubleRegistration,
    partnerId:value.partnerId as number|null ?? null, partnerName:[str(value.partnerFirstName),str(value.partnerLastName)].filter(Boolean).join(' ') || null };
}
export function parsePartners(value: unknown): Partner[] {
  if (!Array.isArray(value) || value.length > 100) throw new AuthError('UNAVAILABLE');
  return value.map(p => {
    if (!rec(p) || !id(p.id) || !str(p.nombre).trim() || !str(p.apellido).trim()) throw new AuthError('UNAVAILABLE');
    // Узкое отображение: email и остальные поля полного PlayerResponseDto не сохраняем.
    return { id:p.id, first:str(p.nombre), last:str(p.apellido), phone:str(p.telefono), telegram:str(p.telegramUsername), level:str(p.nivelJugador) };
  });
}
export function parseCandidates(value: unknown): Candidate[] {
  if (!Array.isArray(value)) throw new AuthError('UNAVAILABLE');
  return value.map(p => {
    if (!rec(p) || !id(p.registrationId) || !id(p.playerId) || !str(p.playerName)) throw new AuthError('UNAVAILABLE');
    return { id:p.registrationId, playerId:p.playerId, name:str(p.playerName), level:str(p.nivel)||null, shareContacts:p.shareContacts===true,
      phone:p.shareContacts===true ? str(p.telefono)||null:null, telegram:p.shareContacts===true ? str(p.telegramUsername)||null:null };
  });
}
export class PairError extends AuthError {
  snapshot?: PairSnapshot; matches?: Partner[];
  constructor(code: string, snapshot?: PairSnapshot, matches?: Partner[]) { super(code); this.snapshot=snapshot; this.matches=matches; }
}
export type PairTransport = {
  contactStatus?: () => Promise<unknown>; sessionVersion: () => number; details: (id:number)=>Promise<PublicTournament>; pairOwn:(id:number)=>Promise<unknown>;
  searchPartners:(id:number,q:string)=>Promise<unknown>; pairCandidates:(id:number)=>Promise<unknown>;
  pairWrite:(id:number,action:'register'|'register-solo'|'add-partner',body:unknown)=>Promise<unknown>;
  proposePair:(id:number,target:number)=>Promise<unknown>;
};
export function createPairBooking(transport:PairTransport, playerId:number|null) {
  const version=transport.sessionVersion(); const pending=new Set<number>(); const uncertain=new Map<number,'register'|'add-partner'|'proposal'>();
  function account() { if (!playerId || version!==transport.sessionVersion()) throw new AuthError('CANCELLED'); }
  async function load(eventId:number):Promise<PairSnapshot> {
    account(); if(!id(eventId)) throw new AuthError('UNAVAILABLE');
    const [event,raw]=await Promise.all([transport.details(eventId),transport.pairOwn(eventId)]); account();
    if(event.id!==eventId) throw new AuthError('UNAVAILABLE'); return { event, own:parseOwn(raw) };
  }
  async function search(eventId:number,q:string) { account(); if(q.trim().length<2)return [];
    const rows=parsePartners(await transport.searchPartners(eventId,q.trim())); account(); return rows.filter(p=>p.id!==playerId); }
  async function candidates(eventId:number) { account(); const rows=parseCandidates(await transport.pairCandidates(eventId)); account(); return rows.filter(p=>p.playerId!==playerId); }
  function guard(s:PairSnapshot) {
    if(!isPairEvent(s.event)) throw new PairError('NOT_PAIR',s);
    if(!s.event.registrationOpen||s.event.status!=='REGISTRO_ABIERTO'||Date.parse(s.event.startsAt)<=Date.now()) throw new PairError('CLOSED',s);
  }
  async function mutate(eventId:number,action:'register'|'add-partner'|'proposal',write:()=>Promise<unknown>,allowed:string[]):Promise<PairReceipt> {
    account();
    try {
      const raw=await write(); account();
      if(!rec(raw)||raw.success!==true||action!=='proposal'&&!allowed.includes(str(raw.status))) throw new Error('Unknown result');
      if(raw.waitlistPosition!=null&&!id(raw.waitlistPosition)) throw new Error('Unknown position');
      return { status:action==='proposal'?'PROPOSAL_SENT':str(raw.status), waitlistPosition:raw.waitlistPosition as number|null ?? null };
    }catch(e) { account(); if(e instanceof PlayerRequestError||e instanceof AuthError&&['RATE_LIMIT','FORBIDDEN'].includes(e.code))throw e;
      uncertain.set(eventId,action); throw new PairError('UNCERTAIN'); }
  }
  async function exclusive<T>(eventId:number,fn:()=>Promise<T>):Promise<T> {
    account(); if(pending.has(eventId))throw new PairError('BUSY'); if(uncertain.has(eventId))throw new PairError('UNCERTAIN');
    pending.add(eventId);try{return await fn();}finally{pending.delete(eventId);}
  }
  return { load,search,candidates,
    async reconcile(eventId:number) {
      const snapshot=await load(eventId); const action=uncertain.get(eventId);
      if(action==='register'&&snapshot.own.registered || action==='add-partner'&&snapshot.own.isDouble&&snapshot.own.partnerId)uncertain.delete(eventId);
      return { snapshot, uncertain:uncertain.has(eventId) };
    },
    async submit(eventId:number,quote:string,mode:PairMode,partner:Partner,shareContacts:boolean,adding=false) {
      return exclusive(eventId,async()=>{
        const s=await load(eventId); guard(s);
        if(pairQuote(s)!==quote)throw new PairError('CHANGED',s);
        if(adding?!canAddPartner(s.own):s.own.registered)throw new PairError('EXISTING',s);
        if(adding&&mode!=='WITH_PARTNER')throw new PairError('UNAVAILABLE');
        if(mode==='WITH_PARTNER') {
          if(!validPartner(partner)||partner.id===playerId)throw new PairError('INVALID_PARTNER',s);
          if(partner.id) { const matches=await search(eventId,partner.first); if(!matches.some(p=>p.id===partner.id)) {
              const byLast=await search(eventId,partner.last); if(!byLast.some(p=>p.id===partner.id))throw new PairError('PARTNER_UNAVAILABLE',s);
            } }
          else {
            if (transport.contactStatus) {
              const contact=await transport.contactStatus(); account(); if(!rec(contact))throw new AuthError('UNAVAILABLE');
              const samePhone=digits(str(contact.telefono)).length>=8&&digits(str(contact.telefono))===digits(partner.phone);
              const tg=(v:string)=>v.trim().replace(/^@/,'').toLowerCase();
              if(samePhone||partner.telegram.trim()&&tg(str(contact.telegramUsername))===tg(partner.telegram))throw new PairError('INVALID_PARTNER',s);
            }
            const matches=[...await search(eventId,partner.phone),...(partner.telegram.trim()?await search(eventId,partner.telegram):[])];
            const unique=[...new Map(matches.map(p=>[p.id,p])).values()]; if(unique.length)throw new PairError('MATCH_REQUIRED',s,unique);
          }
          account();
          const body=partner.id?{nombre:partner.first.trim(),apellido:partner.last.trim(),existingUserId:partner.id,isExistingUser:true}:
            {nombre:partner.first.trim(),apellido:partner.last.trim(),telefono:partner.phone.trim(),telegramUsername:partner.telegram.trim()||null,isExistingUser:false};
          return mutate(eventId,adding?'add-partner':'register',()=>transport.pairWrite(eventId,adding?'add-partner':'register',body),['CONFIRMED','WAITLIST']);
        }
        return mutate(eventId,'register',()=>transport.pairWrite(eventId,'register-solo',{soloType:mode,shareContacts:mode==='SEARCH'&&shareContacts}),mode==='SEARCH'?['SOLO_SEARCH']:['SOLO_ADD_LATER','WAITLIST']);
      });
    },
    async propose(eventId:number,quote:string,targetId:number) {
      return exclusive(eventId,async()=>{const s=await load(eventId);guard(s);
        if(pairQuote(s)!==quote)throw new PairError('CHANGED',s);
        if(!canProposePair(s.own))throw new PairError('EXISTING',s);
        if(!(await candidates(eventId)).some(p=>p.id===targetId))throw new PairError('PARTNER_UNAVAILABLE',s);
        return mutate(eventId,'proposal',()=>transport.proposePair(eventId,targetId),[]);
      });
    },
  };
}
