export function readSharedEventId(search:string):number|null {
 try{const v=new URLSearchParams(search).get('event');if(!v||!/^\d+$/.test(v))return null;const n=Number(v);return Number.isSafeInteger(n)&&n>0?n:null;}catch{return null;}
}
