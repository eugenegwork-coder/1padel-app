import test from 'node:test';
import assert from 'node:assert/strict';
import {AuthError,PlayerRequestError} from '../src/auth.ts';
import {createPairBooking,pairQuote,parseOwn,parsePartners,parseCandidates,canAddPartner,validPartner} from '../src/pairBooking.ts';
import {readSharedEventId} from '../src/sharedEvent.ts';
import {pairCopy} from '../src/pairCopy.ts';
function fixture(){
 const event={id:42,name:'Test pair',type:'AMERICANO_TEAMS',modality:'DOBLES',gender:'MASCULINO',level:'C9',status:'REGISTRO_ABIERTO',registrationOpen:true,startsAt:new Date(Date.now()+4*86400000).toISOString(),timeZone:'America/Argentina/Buenos_Aires',club:{id:1,name:'Test'},price:30000,currency:'ARS',available:1,cancellationDeadline:null,description:null};
 const state={event,own:{registered:false},writes:[],search:[],candidates:[],version:1,result:{success:true,status:'CONFIRMED'}};
 const transport={sessionVersion:()=>state.version,details:async()=>({...state.event}),pairOwn:async()=>({...state.own}),searchPartners:async()=>state.search,pairCandidates:async()=>state.candidates,pairWrite:async(id,action,body)=>{state.writes.push({id,action,body});return state.result;},proposePair:async()=>{state.writes.push({proposal:true});return {success:true};}};
 const partner={first:'New',last:'Partner',phone:'+54 9 11 0000 0999',telegram:''};
 const own=(status='SOLO_ADD_LATER',isDouble=false)=>({registered:true,registrationId:17,status,isDoubleRegistration:isDouble,partnerId:isDouble?20:null,partnerFirstName:isDouble?'Alex':null,partnerLastName:isDouble?'Test':null,waitlistPosition:status==='WAITLIST'?2:null,registrationDate:'2026-10-22T09:00:00'});
 return {state,transport,gateway:createPairBooking(transport,4),partner,own};
}
async function quoted(f){return pairQuote(await f.gateway.load(42));}
test('opening and reading are mutation-free; new partner without email can register a real pair payload',async()=>{
 const f=fixture();const q=await quoted(f);assert.equal(f.state.writes.length,0);
 const receipt=await f.gateway.submit(42,q,'WITH_PARTNER',f.partner,false);
 assert.equal(receipt.status,'CONFIRMED');assert.equal(f.state.writes.length,1);
 assert.equal(f.state.writes[0].action,'register');assert.equal('email' in f.state.writes[0].body,false);assert.equal('playerId' in f.state.writes[0].body,false);
});
test('queue status comes from the server and solo reservation is not confused with a formed pair',async()=>{
 for(const [mode,status]of [['WITH_PARTNER','WAITLIST'],['SEARCH','SOLO_SEARCH'],['ADD_LATER','WAITLIST']]){
  const f=fixture();f.state.result={success:true,status,waitlistPosition:status==='WAITLIST'?3:null};
  const receipt=await f.gateway.submit(42,await quoted(f),mode,f.partner,true);assert.equal(receipt.status,status);
  if(mode!=='WITH_PARTNER')assert.deepEqual(f.state.writes[0].body,{soloType:mode,shareContacts:mode==='SEARCH'});
 }
 assert.equal(canAddPartner(parseOwn(fixture().own('WAITLIST',false))),true);
 assert.equal(canAddPartner(parseOwn(fixture().own('WAITLIST',true))),false);
});
test('ambiguous contacts require explicit selection; no duplicate guest is registered',async()=>{
 const f=fixture();f.state.search=[{id:20,nombre:'Alex',apellido:'One'},{id:21,nombre:'Alex',apellido:'Two'}];
 await assert.rejects(f.gateway.submit(42,await quoted(f),'WITH_PARTNER',f.partner,false),e=>e.code==='MATCH_REQUIRED'&&e.matches.length===2);
 assert.equal(f.state.writes.length,0);
});
test('selected existing partner uses ID and names without overwriting their contacts',async()=>{
 const f=fixture();f.state.search=[{id:20,nombre:'Alex',apellido:'Test',telefono:'+54 9 11 0000 0123',email:'private@example.test'}];
 const partners=await f.gateway.search(42,'Alex');assert.equal('email'in partners[0],false);
 await f.gateway.submit(42,await quoted(f),'WITH_PARTNER',partners[0],false);
 assert.deepEqual(f.state.writes[0].body,{nombre:'Alex',apellido:'Test',existingUserId:20,isExistingUser:true});
});
test('self, missing phone, individual events, closed or started event never send a pair registration',async()=>{
 for(const change of [{modality:'INDIVIDUAL'},{registrationOpen:false},{startsAt:new Date(Date.now()-1000).toISOString()}]){
  const f=fixture();Object.assign(f.state.event,change);await assert.rejects(f.gateway.submit(42,await quoted(f),'WITH_PARTNER',f.partner,false));assert.equal(f.state.writes.length,0);
 }
 const f=fixture();assert.equal(validPartner({...f.partner,phone:''}),false);
 await assert.rejects(f.gateway.submit(42,await quoted(f),'WITH_PARTNER',{...f.partner,id:4},false));assert.equal(f.state.writes.length,0);
});
test('changed conditions or newly created own request require another review, zero POST',async()=>{
 for(const change of [{price:32000},{available:0}]){const f=fixture();const q=await quoted(f);Object.assign(f.state.event,change);
 await assert.rejects(f.gateway.submit(42,q,'WITH_PARTNER',f.partner,false),{code:'CHANGED'});assert.equal(f.state.writes.length,0);}
 const f=fixture();const q=await quoted(f);f.state.own=f.own();await assert.rejects(f.gateway.submit(42,q,'WITH_PARTNER',f.partner,false),{code:'CHANGED'});
});
test('add partner edits an existing eligible solo request and preserves reserve status from server',async()=>{
 const f=fixture();f.state.own=f.own('WAITLIST');f.state.result={success:true,status:'WAITLIST'};
 await f.gateway.submit(42,await quoted(f),'WITH_PARTNER',f.partner,false,true);assert.equal(f.state.writes[0].action,'add-partner');
 f.state.own=f.own('WAITLIST',true);await assert.rejects(f.gateway.submit(42,await quoted(f),'WITH_PARTNER',f.partner,false,true),{code:'EXISTING'});
});
test('double taps send one write; switching account during preflight sends none',async()=>{
 const f=fixture();let reply;f.transport.pairWrite=()=>{f.state.writes.push({});return new Promise(resolve=>{reply=resolve;});};const g=createPairBooking(f.transport,4);const q=pairQuote(await g.load(42));
 const first=g.submit(42,q,'WITH_PARTNER',f.partner,false);await assert.rejects(g.submit(42,q,'WITH_PARTNER',f.partner,false),{code:'BUSY'});
 await new Promise(resolve=>setImmediate(resolve));reply({success:true,status:'CONFIRMED'});await first;assert.equal(f.state.writes.length,1);
 const h=fixture();let finish;h.transport.details=()=>new Promise(resolve=>{finish=resolve;});const gh=createPairBooking(h.transport,4);const p=gh.load(42);h.state.version++;finish(h.state.event);await assert.rejects(p,{code:'CANCELLED'});
});
test('lost response and 401 renewal cannot replay POST; active solo before a lost add is not proof of completion',async()=>{
 const f=fixture();f.state.own=f.own();f.transport.pairWrite=async()=>{f.state.writes.push({});throw new AuthError('REVIEW_REQUIRED');};const g=createPairBooking(f.transport,4);const q=pairQuote(await g.load(42));
 await assert.rejects(g.submit(42,q,'WITH_PARTNER',f.partner,false,true),{code:'UNCERTAIN'});
 assert.equal((await g.reconcile(42)).uncertain,true);await assert.rejects(g.submit(42,q,'WITH_PARTNER',f.partner,false,true),{code:'UNCERTAIN'});
 f.state.own=f.own('CONFIRMED',true);assert.equal((await g.reconcile(42)).uncertain,false);assert.equal(f.state.writes.length,1);
});
test('backend rejection preserves needLevel; unknown success/status never invents confirmed pair',async()=>{
 const f=fixture();f.transport.pairWrite=async()=>{throw new PlayerRequestError({needLevel:true,message:'level'});};const g=createPairBooking(f.transport,4);
 await assert.rejects(g.submit(42,pairQuote(await g.load(42)),'WITH_PARTNER',f.partner,false),e=>e.needLevel);
 for(const result of [{success:true,status:'PARTNER_INVITED'},{success:'true',status:'CONFIRMED'},{}]){const h=fixture();h.state.result=result;await assert.rejects(h.gateway.submit(42,await quoted(h),'WITH_PARTNER',h.partner,false),{code:'UNCERTAIN'});}
});
test('proposal requires own solo and a currently available target; does not return a confirmed pair',async()=>{
 const f=fixture();f.state.own=f.own('SOLO_SEARCH');f.state.candidates=[{registrationId:25,playerId:20,playerName:'Candidate',shareContacts:false,telefono:'private',telegramUsername:'private'}];
 const candidates=await f.gateway.candidates(42);assert.equal(candidates[0].phone,null);assert.equal(candidates[0].telegram,null);
 assert.equal((await f.gateway.propose(42,await quoted(f),25)).status,'PROPOSAL_SENT');
 f.state.candidates=[];await assert.rejects(f.gateway.propose(42,await quoted(f),25),{code:'PARTNER_UNAVAILABLE'});
});
test('malformed own contract fails closed; event link opens only details, no stored intent or automatic signup',async()=>{
 assert.throws(()=>parseOwn({registered:true,status:'WAITLIST'}));
 assert.throws(()=>parsePartners({}));assert.throws(()=>parseCandidates([{}]));
 assert.equal(readSharedEventId('?event=42'),42);for(const query of ['?event=-1','?event=NaN','?event=9007199254740992','?event=1x'])assert.equal(readSharedEventId(query),null);
 assert.deepEqual(Object.keys(pairCopy.ru).sort(),Object.keys(pairCopy.es).sort());assert.deepEqual(Object.keys(pairCopy.ru).sort(),Object.keys(pairCopy.en).sort());
});
test('own WhatsApp in another formatting or own Telegram cannot create a guest partner for self',async()=>{
 for(const contact of [{telefono:'+54 (9) 11 0000-0999'},{telegramUsername:'@SELF_USER'}]){
  const f=fixture();f.transport.contactStatus=async()=>contact;const g=createPairBooking(f.transport,4);
  await assert.rejects(g.submit(42,pairQuote(await g.load(42)),'WITH_PARTNER',{...f.partner,telegram:'@self_user'},false),{code:'INVALID_PARTNER'});assert.equal(f.state.writes.length,0);
 }
});
